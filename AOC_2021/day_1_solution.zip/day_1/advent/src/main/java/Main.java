
import java.io.*;
import java.util.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author samue
 */
public class Main {
    
    public static void main(String[] args) throws IOException {
        int count = 0;
        
        List<String>  aList = new ArrayList<>();
        File aFile = new File("input.txt");
        
        try (BufferedReader br = new BufferedReader(new FileReader(aFile))) 
        {
            while (br.ready()) {
            aList.add(br.readLine());
        }
        }
        catch(IOException anException)
        {
            System.out.println("file not found");
        }
        
        for(int i = 0; i < aList.size()-1; i++)
        {
            if(i+3 > aList.size()-1)
            {
                break;
            }
            int window1 = Integer.parseInt(aList.get(i)) + Integer.parseInt(aList.get(i+1)) + Integer.parseInt(aList.get(i+2));
            int window2 = Integer.parseInt(aList.get(i+1)) + Integer.parseInt(aList.get(i+2)) + Integer.parseInt(aList.get(i+3));
            
            if(window1 < window2)
            {
                count++;
            }
        }
        
        
        System.out.print(count);
    }
    
}
